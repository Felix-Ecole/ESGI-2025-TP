class SecureUser {
	static textToBinary(texte) {
		return [...texte].map(c => c.charCodeAt(0).toString(2)).join(' ');
	}

	static binaryToText(binary) {
		return binary.split(' ').map(b => String.fromCharCode(parseInt(b, 2))).join('');
	}

	static encrypt(key, data) {

	}

	static decrypt(key, data) {

	}
}